//Node Console just to show how it works, very simple.

console.log("hello world");
