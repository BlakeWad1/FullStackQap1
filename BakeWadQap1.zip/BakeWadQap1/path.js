const path = require("node:path");
path.posix.basename("/tmp/myfile.html");
// Returns: 'myfile.html'
console.log(path);
