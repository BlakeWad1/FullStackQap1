console.error(new Error("Oh shit what happened"));

class FancyError extends Error {
  constructor(args) {
    super(args);
    this.name = "FancyError";
  }
}

console.log(new Error("A standard error"));
// { [Error: A standard error] }

console.log(new FancyError("An augmented error"));
// { [Your fancy error: An augmented error] name: 'FancyError' }
