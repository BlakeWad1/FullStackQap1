//Lodash is a utility library that makes JavaScript easier by taking the hassle out of working with arrays, numbers, objects, strings, etc.
const _ = require("lodash");
const nums = _.range(1, 9);
// => [1, 2, 3, 4, 5, 6, 7, 8, 9]
const chunks = _.chunk(nums, 3);
// => [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
const right = _.takeRight(nums, 2);
// => [7, 8, 9]
console.log(nums);
console.log(chunks);
console.log(right);

//Date-fns provides the most comprehensive, yet simple and consistent toolset for manipulating JavaScript dates in a browser & Node.js.
const { format } = require("date-fns");
console.log(format(new Date(), "yyyyMMdd\tHH:mm:ss")); //Date will be given in year,month,day and time in hours,minutes,seconds.

//Validator is a library of string validators and sanitizers.
var validator = require("validator");
validator.isEmail("foo@bar.com"); //=> true
console.log(validator);
