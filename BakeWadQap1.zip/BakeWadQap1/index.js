// node http to create a server
const http = require("http");
const port = 3000;

//create a server object:
const server = http.createServer((request, response) => {
  response.writeHead(200, { "Content-Type": "text/plain" });
  response.end("Hello Keyin world! response")("Hello World!"); //write a response to the client and end
});

server.listen(port, () =>
  console.log(
    `server started on port ${port}; ` + "press Ctrl-C to terminate...."
  )
); //the server object listens on port 3000
